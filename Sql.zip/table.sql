create database amritulya;
use amritulya;

CREATE TABLE `emailcredentials` (
  `emailID` varchar(255) DEFAULT NULL,
  `emailPass` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `placedorders` (
  `orderID` int(10) NOT NULL AUTO_INCREMENT,
  `orderCustomerID` int(10) DEFAULT NULL,
  `orderFirstName` varchar(255) DEFAULT NULL,
  `orderLastName` varchar(255) DEFAULT NULL,
  `orderProductName` varchar(2047) DEFAULT NULL,
  `orderProductID` int(10) DEFAULT NULL,
  `orderDate` varchar(255) DEFAULT NULL,
  `orderAddress` varchar(2047) DEFAULT NULL,
  `orderEmail` varchar(255) DEFAULT NULL,
  `orderAmount` varchar(255) DEFAULT NULL,
  `orderQuantity` varchar(255) DEFAULT NULL,
  `orderStatus` varchar(255) DEFAULT 'Confirmed',
  `shipmentCompany` varchar(2047) DEFAULT 'NA',
  `shipmentID` varchar(255) DEFAULT 'NA',
  `orderType` varchar(45) DEFAULT 'C',
  `orderPhone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`orderID`),
  KEY `orderCustomerID` (`orderCustomerID`),
  KEY `orderProductID` (`orderProductID`),
  CONSTRAINT `placedorders_ibfk_1` FOREIGN KEY (`orderCustomerID`) REFERENCES `registeruser` (`userid`),
  CONSTRAINT `placedorders_ibfk_2` FOREIGN KEY (`orderProductID`) REFERENCES `subproductslg` (`subProductIDLG`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

CREATE TABLE `productCategoryAmritulya` (
  `prdCategoryLGID` int(10) NOT NULL AUTO_INCREMENT,
  `prodCategoryLGName` varchar(2047) DEFAULT NULL,
  `prodAddedBy` varchar(255) DEFAULT NULL,
  `prodAddedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`prdCategoryLGID`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `productslg` (
  `productIdLG` int(10) NOT NULL AUTO_INCREMENT,
  `productNameLG` varchar(2047) DEFAULT NULL,
  `productDescriptionLG` varchar(2047) DEFAULT NULL,
  `productImgNameLG` varchar(255) DEFAULT NULL,
  `productCategory` int(10) DEFAULT NULL,
  `productAvailability` varchar(255) DEFAULT NULL,
  `productRank` int(10) DEFAULT NULL,
  `productAddedBy` varchar(255) DEFAULT NULL,
  `productAddDate` datetime DEFAULT NULL,
  PRIMARY KEY (`productIdLG`),
  KEY `productCategory` (`productCategory`),
  CONSTRAINT `productslg_ibfk_1` FOREIGN KEY (`productCategory`) REFERENCES `productCategoryAmritulya` (`prdCategoryLGID`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `subproductslg` (
  `subProductIDLG` int(10) NOT NULL AUTO_INCREMENT,
  `subproductNameLG` varchar(2047) DEFAULT NULL,
  `subproductPriceLG` int(255) DEFAULT NULL,
  `subproductDescriptionLG` varchar(2047) DEFAULT NULL,
  `subproductImgNameLG` varchar(255) DEFAULT NULL,
  `subproductCategory` int(10) DEFAULT NULL,
  `subproductAvailability` varchar(255) DEFAULT NULL,
  `subproductRank` int(10) DEFAULT NULL,
  `subproductAddedBy` varchar(255) DEFAULT NULL,
  `subproductAddDate` datetime DEFAULT NULL,
  `subproductWeight` varchar(255) DEFAULT NULL,
  `subproductColors` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`subProductIDLG`),
  KEY `subproductCategory` (`subproductCategory`),
  CONSTRAINT `subproductslg_ibfk_1` FOREIGN KEY (`subproductCategory`) REFERENCES `productslg` (`productIdLG`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

CREATE TABLE `registeruser` (
  `userid` int(10) NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) DEFAULT NULL,
  `userEmail` varchar(2047) DEFAULT NULL,
  `userContact` varchar(255) DEFAULT NULL,
  `userPassword` varchar(2047) DEFAULT NULL,
  `userType` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;





