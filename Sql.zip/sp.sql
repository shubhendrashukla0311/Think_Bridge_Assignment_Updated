DELIMITER $$
CREATE  PROCEDURE `addProdCategory`(in categoryName varchar(2047),in prdAddBy varchar(255))
begin
set @addName = (select userName from registeruser where userEmail=prdAddBy);
insert into productCategoryAmritulya (prodCategoryLGName,prodAddedBy,prodAddedDate) values (categoryName,@addName,current_date());
end$$
DELIMITER ;
drop procedure addProduct;
DELIMITER $$
CREATE  PROCEDURE `addProduct`(in pName varchar(2047),in pDesc varchar(2047), in pImgName varchar(255),in pCat varchar(2047),in pAddBy varchar(255))
begin
set @addName = (select userName from registeruser where userEmail=pAddBy);
set @catID=(select prdCategoryLGID from productCategoryAmritulya where prodCategoryLGName=pCat);
set @checkRank = (select count(productIdLG) from productslg where productCategory=@catID);
if(@checkRank <> 0)
then
set @maxRank = (select max(productRank) from productslg where productCategory=@catID);
set @nextRank= @maxRank + 1;
insert into productslg (productNameLG,productDescriptionLG,productImgNameLG,productCategory,productAvailability,productRank,productAddedBy,productAddDate) values
(pName,pDesc,pImgName,@catID,"Available",@nextRank,@addName,current_date());
end if;
if(@checkRank = 0)
then
insert into productslg (productNameLG,productDescriptionLG,productImgNameLG,productCategory,productAvailability,productRank,productAddedBy,productAddDate) values
(pName,pDesc,pImgName,@catID,"Available",1,@addName,current_date());
end if;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `addSubProduct`(in spName varchar(2047),in spPrice int(255),in spDesc varchar(2047), in spImgName varchar(255),in spCat varchar(2047),in spAddBy varchar(255))
begin
set @addName = (select userName from registeruser where userEmail=spAddBy);
set @catID=(select productIdLG from productslg where productNameLG=spCat);
set @checkRank = (select count(subproductIdLG) from subproductslg where subproductCategory=@catID);
if(@checkRank <> 0)
then
set @maxRank = (select max(subproductRank) from subproductslg where subproductCategory=@catID);
set @nextRank= @maxRank + 1;
insert into subproductslg (subproductNameLG,subproductPriceLG,subproductDescriptionLG,subproductImgNameLG,subproductCategory,subproductAvailability,subproductRank,subproductAddedBy,subproductAddDate) values
(spName,spPrice,spDesc,spImgName,@catID,"Available",@nextRank,@addName,current_date());
end if;
if(@checkRank = 0)
then
insert into subproductslg (subproductNameLG,subproductPriceLG,subproductDescriptionLG,subproductImgNameLG,subproductCategory,subproductAvailability,subproductRank,subproductAddedBy,subproductAddDate) values
(spName,spPrice,spDesc,spImgName,@catID,"Available",1,@addName,current_date());
end if;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `adminUser`(in aName varchar(255), in aEmail varchar(2047),in aContact varchar(255), in aPassword varchar(2047))
begin
set @flag= (select count(userid) from registeruser where userEmail = aEmail);
if(@flag = 0)
then
insert into registeruser (userName,userEmail,userContact,userPassword,userType) values (aName,aEmail,aContact,aPassword,"admin");
end if;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `checkExistingUser`(in uEmail varchar(2047))
begin
set @flag= (select count(userid) from registeruser where userEmail = uEmail);
if(@flag = 0)
then
select "True" as result;
end if;
if(@flag <> 0)
then
select "False" as result;
end if;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `deleteAdmin`(in aID int(10))
begin
delete from registeruser where userid=aID;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `deleteCategory`(in catID int(10))
begin
delete from productCategoryAmritulya where prdCategoryLGID=catID;
end$$
DELIMITER ;

drop procedure deleteCategory;

DELIMITER $$
CREATE  PROCEDURE `deleteProduct`(in prID int(10))
begin
set @rankProduct=(select productRank from productslg where productIdLG=prID);
set @prCat = (select productCategory from productslg where productIdLG=prID);
set @catMaxRank = (select max(productRank) from productslg where productCategory = @prCat);
delete from productslg where productIdLG=prID;
if(@rankProduct = 1)
then
set @nextRankExists = (select count(productIdLG) from productslg where productRank=2 and productCategory = @prCat);
if(@nextRankExists = 1)
then
#set @nextRankPrID = (select productIdLG from productslg where productRank=2 and productCategory = @prCat);
update productslg set productRank = (productRank - 1) where productCategory = @prCat;
end if;
end if;
if(@rankProduct <> 1 and @rankProduct<>@catMaxRank)
then
update productslg set productRank = (productRank - 1) where productCategory = @prCat and productRank > @rankProduct;
end if;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `deleteSubProduct`(in sprID int(10))
begin
set @rankProduct=(select subproductRank from subproductslg where subproductIdLG=sprID);
set @prCat = (select subproductCategory from subproductslg where subproductIdLG=sprID);
set @catMaxRank = (select max(subproductRank) from subproductslg where subproductCategory = @prCat);
delete from subproductslg where subproductIdLG=sprID;
if(@rankProduct = 1)
then
set @nextRankExists = (select count(subproductIdLG) from subproductslg where subproductRank > @rankProduct and subproductCategory = @prCat);
if(@nextRankExists > 0)
then
#set @nextRankPrID = (select productIdLG from productslg where productRank=2 and productCategory = @prCat);
update subproductslg set subproductRank = (subproductRank - 1) where subproductCategory = @prCat;
end if;
end if;
if(@rankProduct <> 1 and @rankProduct<>@catMaxRank)
then
update subproductslg set subproductRank = (subproductRank - 1) where subproductCategory = @prCat and subproductRank > @rankProduct;
end if;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `editCategoryDetail`(in categoryName varchar(2047),in prdAddBy varchar(255),in catID int(10))
begin
update productCategoryAmritulya set prodCategoryLGName=categoryName, prodAddedBy = prdAddBy where prdCategoryLGID=catID;
end$$
DELIMITER ;

drop procedure fetchCategoryDetails;

DELIMITER $$
CREATE  PROCEDURE `fetchCategoryDetails`(in catID int(10))
begin
select * from productCategoryAmritulya where prdCategoryLGID=catID;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `listAdmins`(in uEmail varchar(255))
begin
select * from registeruser where userType="admin" and userEmail <> uEmail;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `listAllOrders`()
begin
select * from placedorders order by orderID desc;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `listFilteredOrders`(in keyw varchar(255))
begin
if(keyw = "All")
then
select * from placedorders order by orderID desc;
end if;
if(keyw = "Date")
then
select * from placedorders order by orderDate desc;
end if;
if(keyw = "Amount")
then
select * from placedorders order by cast(orderAmount as signed) desc;
end if;
if(keyw = "Confirmed")
then
select * from placedorders where orderStatus="Confirmed" order by orderID desc;
end if;
if(keyw = "Shipped")
then
select * from placedorders where orderStatus="Shipped" order by orderID desc;
end if;
if(keyw = "Delivered")
then
select * from placedorders where orderStatus="Delivered" order by orderID desc;
end if;
if(keyw = "Today")
then
select * from placedorders where orderDate=current_date() order by orderID desc;
end if;
if(keyw = "Guest")
then
select * from placedorders where orderType="G" order by orderID desc;
end if;
if(keyw = "Customer")
then
select * from placedorders where orderType="C" order by orderID desc;
end if;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `listProducts`()
begin
select P.*,PC.prodCategoryLGName as CategoryName from productslg P join productCategoryAmritulya PC on P.productCategory = PC.prdCategoryLGID  order by P.productCategory,P.productRank desc;
end$$
DELIMITER ;

drop procedure listProducts;

DELIMITER $$
CREATE  PROCEDURE `listSubProducts`()
begin
select SP.*,P.productNameLG as CategoryName from subproductslg SP join productslg P on SP.subproductCategory = P.productIdLG  order by SP.subproductCategory,SP.subproductRank desc;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `loadProduct`(in prID int(10))
begin
select P.*,PC.prodCategoryLGName as CategoryName from productslg P join productCategoryAmritulya PC on P.productCategory = PC.prdCategoryLGID  where P.productIdLG=prID  order by P.productCategory,P.productRank desc;
end$$
DELIMITER ;
drop procedure loadProduct;
DELIMITER $$
CREATE  PROCEDURE `loadSubProduct`(in sprID int(10))
begin
select P.productNameLG as CategoryName,SP.*  from productslg P join subproductslg SP on P.productIdLG = SP.subproductCategory  where SP.subproductIdLG=sprID  order by SP.subproductCategory,SP.subproductRank asc;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `orderDetail`(in ordID int(10))
begin
select * from placedorders where orderID = ordID;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `placeOrder`(in uEmail varchar(2047), in productID varchar(255),in orderAddr varchar(2047),in ordQuant varchar(255),in ordAmt varchar(255),in ordFN varchar(255),in ordLstName varchar(255),in prdName varchar(2047),in ordPhn varchar(255))
begin
set @cCount=(select count(userid) from registeruser where userEmail=uEmail);
if(@cCount = 1)
then
set @custId = (select userid from registeruser where userEmail=uEmail);
insert into placedorders (orderCustomerID,orderProductID,orderDate,orderAddress,orderEmail,orderAmount,orderQuantity,orderFirstName,orderLastName,orderProductName,orderPhone) values (@custId,productID,current_date(),orderAddr,uEmail,ordAmt,ordQuant,ordFN,ordLstName,prdName,ordPhn);
end if;
if(@cCount = 0)
then
insert into placedorders (orderCustomerID,orderProductID,orderDate,orderAddress,orderEmail,orderAmount,orderQuantity,orderFirstName,orderLastName,orderProductName,orderType,orderPhone) values (1,productID,current_date(),orderAddr,uEmail,ordAmt,ordQuant,ordFN,ordLstName,prdName,"G",ordPhn);
end if;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `registerUser`(in uName varchar(255), in uEmail varchar(2047), in uContact varchar(255), in uPassword varchar(2047))
begin
set @flag= (select count(userid) from registeruser where userEmail = uEmail);
if(@flag = 0)
then
insert into registeruser (userName,userEmail,userContact,userPassword,userType) values (uName,uEmail,uContact,uPassword,"user");
end if;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `showCustomerOrder`(in uEmail varchar(2047))
begin
set @cID=(select userid from registeruser where userEmail=uEmail);
select subproductslg.subproductImgNameLG,placedorders.* from placedorders inner join subproductslg on placedorders.orderProductName = subproductslg.subproductNameLG where placedorders.orderCustomerID=@cID order by placedorders.orderID desc;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `showEmail`()
begin
select * from emailcredentials;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `updateOrders`(in ordID int(10),in ordStatus varchar(255),in shipComp varchar(2047),in shipID varchar(255))
begin
update placedorders set orderStatus=ordStatus,shipmentCompany=shipComp,shipmentID=shipID where orderID=ordID;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `updateProdImg`(in prID int(10),in pImg varchar(255))
begin
update productslg set productImgNameLG=pImg where productIdLG=prID;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `updateProductDetails`(in prID int(10), in pName varchar(2047),in pRank int(10), in pDesc varchar(2047),in pStatus varchar(255))
begin
update productslg set productNameLG=pName,productRank=pRank, productDescriptionLG=pDesc, productAvailability=pStatus where productIdLG=prID;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `updatesubProdImg`(in sprID int(10),in spImg varchar(255))
begin
update subproductslg set subproductImgNameLG=spImg where subproductIdLG=sprID;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `updateSubProductDetails`(in sprID int(10), in spName varchar(2047),in spRank int(10),in spPrice int(255), in spDesc varchar(2047),in spStatus varchar(255))
begin
update subproductslg set subproductNameLG=spName, subproductPriceLG=spPrice,subproductRank=spRank, subproductDescriptionLG=spDesc, subproductAvailability=spStatus where subproductIdLG=sprID;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `verifyUser`(in uEmail varchar(2047),in uPassword varchar(255))
begin
set @userCount = (select count(userid) from registeruser where userEmail=uEmail);

if(@userCount = 0)
then
select "Not Found" as result,"" as userType;
end if;
if(@userCount =1)
then
set @uPass = (select userPassword from registeruser where userEmail = uEmail);
if(@uPass = uPassword)
then
set @usrType=(select userType from registeruser where userEmail=uEmail);
select "Valid" as result,@usrType as userType;
end if;
if(@uPass <> uPassword)
then
select "Invalid" as result,"" as userType;
end if;
end if;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `viewProductCategory`()
begin
select * from productCategoryAmritulya;
end$$
DELIMITER ;
drop procedure viewProductCategory;
DELIMITER $$
CREATE  PROCEDURE `viewProductTiles`(in cat varchar(255))
begin
select * from productslg where productAvailability="Available" and productCategory= cat order by productRank;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `viewSubProductDetail`(in subID int(10))
begin
select * from subproductslg where subProductIDLG=subID;
end$$
DELIMITER ;

DELIMITER $$
CREATE  PROCEDURE `viewSubProductTiles`(in cat varchar(255))
begin
select *,p.productNameLG from subproductslg sp join productslg p  on sp.subproductCategory = p.productIdLG and sp.subproductAvailability="Available" and sp.subproductCategory= cat order by subproductRank;
end$$
DELIMITER ;



































