﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Amritulya.Models;
using MySql.Data.MySqlClient;

namespace Amritulya.Controllers
{
    public class ProductTileController : Controller
    {
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
       
        public ActionResult viewKitProductTiles()
        {
            string name = "";
            try
            {
                HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
                if (authCookie != null)
                {
                    FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
                    name = ticket.Name;
                }
            }
            catch(Exception ex)
            { }
            
                 
            var model = new List<Product>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("viewProductTiles", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("cat", "1");
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int c = dtbl.Rows.Count;
                for (int i = 0; i < c; i++)
                {
                    var pr = new Product();
                    pr.productNameLG = dtbl.Rows[i]["productNameLG"].ToString();
                    string img = dtbl.Rows[i]["productImgNameLG"].ToString();
                    pr.productImgNameLG = "/ProductImgs/" + img;
                    pr.productDescriptionLG = dtbl.Rows[i]["productDescriptionLG"].ToString();                   
                    pr.productIdLG = Convert.ToInt32(dtbl.Rows[i]["productIdLG"].ToString());
                    pr.productCategory = "Food Orders";
                    model.Add(pr);
                }
                if (name != "")
                {
                    return View("viewKitTiles", model);

                }
                else
                {
                    return View("viewKitGuestTiles", model);
                }
                
            }         
        }

       
        public ActionResult viewGardeningProductTiles()
        {
            string name = "";
            try
            {
                HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
                if (authCookie != null)
                {
                    FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
                    name = ticket.Name;
                }
            }
            catch(Exception ex) { }

            var model = new List<Product>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("viewProductTiles", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("cat", "2");
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int c = dtbl.Rows.Count;
                for (int i = 0; i < c; i++)
                {
                    var pr = new Product();
                    pr.productNameLG = dtbl.Rows[i]["productNameLG"].ToString();
                    string img = dtbl.Rows[i]["productImgNameLG"].ToString();
                    pr.productImgNameLG = "/ProductImgs/" + img;
                    pr.productDescriptionLG = dtbl.Rows[i]["productDescriptionLG"].ToString();
                    pr.productIdLG = Convert.ToInt32(dtbl.Rows[i]["productIdLG"].ToString());
                    pr.productCategory = "Raw Materials";
                    model.Add(pr);
                }
                if (name != "")
                {
                    return View("viewKitTiles", model);

                }
                else
                {
                    return View("viewKitGuestTiles", model);
                }

            }
        }
    }
}