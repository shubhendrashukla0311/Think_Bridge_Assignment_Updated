﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Amritulya.Models;
using MySql.Data.MySqlClient;

namespace Amritulya.Controllers
{
    [Authorize]
    public class ProductController : Controller
    {
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        private List<ProductCategory> loadCategory()
        {
            var l = new List<ProductCategory>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring)) //to create a new sql connection
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("viewProductCategory", sqlCon); //stored procedure to view all products
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                sqlCon.Close();
                int c = dtbl.Rows.Count;

                for (int k = 0; k < c; k++)
                {
                    var ct = new ProductCategory();
                    ct.categoryName = (dtbl.Rows[k]["prodCategoryLGName"].ToString());
                    l.Add(ct);
                }
                return l;
            }
        }
        // GET: Product
        public ActionResult addProduct()
        {
            var model = new List<Product>();
            var list = new List<ProductCategory>();
            list = loadCategory();
            var p = new Product();
            p.category = list;
            model.Add(p);
            return View("createProduct", model);
        }

        [HttpPost]
        
        public ActionResult addProduct(Product pr, HttpPostedFileBase file)
        {
            //    
            //}
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;
            string imgName = "default.png";
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open();
                MySqlCommand sqlCmd = new MySqlCommand("addProduct", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("pName", pr.productNameLG.Trim());
                sqlCmd.Parameters.AddWithValue("pDesc", pr.productDescriptionLG);
                sqlCmd.Parameters.AddWithValue("pCat", pr.productCategory);
                sqlCmd.Parameters.AddWithValue("pAddBy", name);
                if (file != null)
                    imgName = uploadImage(file);
                sqlCmd.Parameters.AddWithValue("pImgName", imgName); //image name
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();
                TempData["msg"] = "<script>alert('Book Added Successfully');</script>";
            }
            return  RedirectToAction("listProducts", "ManageProduct");//redirect to 
        }
        
        private string uploadImage(HttpPostedFileBase file)
        {
            string uploadFolder = Request.PhysicalApplicationPath + "ProductImgs\\"; //upload folder
            var myUniqueFileName = string.Format(@"{0}", Guid.NewGuid()); //GENERATE A UNIQUE FILE NAME
            string extension = System.IO.Path.GetExtension(file.FileName);
            if (file != null)
            {

                file.SaveAs(uploadFolder + myUniqueFileName + extension);

            }
            return myUniqueFileName + extension;

        }
    }
}