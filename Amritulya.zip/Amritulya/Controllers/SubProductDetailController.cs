﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Amritulya.Models;
using MySql.Data.MySqlClient;

namespace Amritulya.Controllers
{
    public class SubProductDetailController : Controller
    {
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: SubProductDetail
        public ActionResult displaySubProductDetail(string spid)
        {
            string name = "";
            try
            {
                HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
                if (authCookie != null)
                {
                    FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
                    name = ticket.Name;
                }
            }
            catch(Exception ex) { }

            //var model = new List<SubProduct>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("viewSubProductDetail", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("subID", spid);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int count = dtbl.Rows.Count;
                var pr = new SubProduct();
                if (count != 0)
                {

                    pr.subproductNameLG = dtbl.Rows[0]["subproductNameLG"].ToString();
                    string img = dtbl.Rows[0]["subproductImgNameLG"].ToString();
                    pr.subproductImgNameLG = "/SubProdImgs/" + img;
                    pr.subproductDescriptionLG = dtbl.Rows[0]["subproductDescriptionLG"].ToString();
                    pr.subproductIdLG = Convert.ToInt32(dtbl.Rows[0]["subproductIdLG"].ToString());
                    pr.subproductPriceLG = "₹​ " + dtbl.Rows[0]["subproductPriceLG"].ToString();
                    if (dtbl.Rows[0]["subproductWeight"].ToString() != "0")
                        pr.subproductWeight = dtbl.Rows[0]["subproductWeight"].ToString();
                    else
                        pr.subproductWeight = "";
                    if (dtbl.Rows[0]["subproductColors"].ToString() != "NA")
                        pr.subproductColors = dtbl.Rows[0]["subproductColors"].ToString();
                    else
                        pr.subproductColors = "";
                }
                else
                { 
                    pr.subproductNameLG = "NA";
                    //string img = dtbl.Rows[0]["subproductImgNameLG"].ToString();
                    pr.subproductImgNameLG = "/SubProdImgs/default.png";
                    pr.subproductDescriptionLG = "NA";
                    pr.subproductIdLG = Convert.ToInt32(0);
                    pr.subproductPriceLG = "NA";
                }
                if (name != "")
                {
                    return View("subProductDetailView", pr); //show with logged in user

                }
                else
                {
                    return View("subProductDetailGuestView", pr); //show with guest user
                }
            }
        }
    }
}