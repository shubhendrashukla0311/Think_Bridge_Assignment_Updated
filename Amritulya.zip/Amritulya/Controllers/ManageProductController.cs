﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Amritulya.Models;
using MySql.Data.MySqlClient;

namespace Amritulya.Controllers
{
    [Authorize]
    public class ManageProductController : Controller
    {
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: ManageProduct
        public ActionResult listProducts()
        {
            var model = new List<Product>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("listProducts", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                //sqlDA.SelectCommand.Parameters.AddWithValue("bOwner", name);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int c = dtbl.Rows.Count;
                for (int i = 0; i < c; i++)
                {
                    var pr = new Product();
                    pr.productNameLG = dtbl.Rows[i]["productNameLG"].ToString();
                    string img = dtbl.Rows[i]["productImgNameLG"].ToString();
                    pr.productImgNameLG = "/ProductImgs/" + img;
                    pr.productCategory = dtbl.Rows[i]["CategoryName"].ToString();
                    pr.productAvailability = dtbl.Rows[i]["productAvailability"].ToString();
                    pr.productIdLG = Convert.ToInt32(dtbl.Rows[i]["productIdLG"].ToString());
                    pr.productRank = Convert.ToInt32(dtbl.Rows[i]["productRank"].ToString());
                    pr.productAddedBy= dtbl.Rows[i]["productAddedBy"].ToString();
                    DateTime dt = Convert.ToDateTime(dtbl.Rows[i]["productAddDate"].ToString());
                    pr.productAddDate = dt.ToString("dd/MM/yyyy");
                    model.Add(pr);
                }
                return View("productDisplay", model);
            }
        }


        public ActionResult deleteProduct(string pid)
        {
            try
            {
                using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
                {
                    sqlCon.Open();
                    MySqlCommand sqlCmd = new MySqlCommand("deleteProduct", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("prID", pid.Trim());
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
            }
            catch(Exception ex)
            {

            }
            return RedirectToAction("listProducts", "ManageProduct");
        }

        
        public ActionResult editProduct(string pid)
        {
            var list = new List<ProductCategory>();
            list = loadCategory();
            var p = new Product();
            p.category = list;

            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("loadProduct", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("prID", pid);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                //var bk = new book();
                p.productNameLG = dtbl.Rows[0]["productNameLG"].ToString();
                string img = dtbl.Rows[0]["productImgNameLG"].ToString();
                p.productImgNameLG = "/ProductImgs/" + img;
                p.productCategory = dtbl.Rows[0]["CategoryName"].ToString();
                p.productIdLG =Convert.ToInt32(dtbl.Rows[0]["productIdLG"].ToString());
                p.productRank =Convert.ToInt32(dtbl.Rows[0]["productRank"].ToString());
                p.productDescriptionLG = dtbl.Rows[0]["productDescriptionLG"].ToString();
                p.productAvailability = dtbl.Rows[0]["productAvailability"].ToString();
                //cp.empId = dtbl.Rows[i]["empId"].ToString();                           
                return View("productEditor", p);
            }
            //return View();
        }

        private List<ProductCategory> loadCategory()
        {
            var l = new List<ProductCategory>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring)) //to create a new sql connection
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("viewProductCategory", sqlCon); //stored procedure to view all products
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                sqlCon.Close();
                int c = dtbl.Rows.Count;

                for (int k = 0; k < c; k++)
                {
                    var ct = new ProductCategory();
                    ct.categoryName = (dtbl.Rows[k]["prodCategoryLGName"].ToString());
                    l.Add(ct);
                }
                return l;
            }
        }
        [HttpPost]
        
        public ActionResult updateProduct(Product p)
        {
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open();
                MySqlCommand sqlCmd = new MySqlCommand("updateProductDetails", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("prID", p.productIdLG);
                sqlCmd.Parameters.AddWithValue("pName", p.productNameLG.Trim());
                sqlCmd.Parameters.AddWithValue("pRank", p.productRank.ToString().Trim());
                sqlCmd.Parameters.AddWithValue("pDesc", p.productDescriptionLG);
                sqlCmd.Parameters.AddWithValue("pStatus", p.productAvailability);
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();
                //TempData["msg"] = "<script>alert('Book Added Successfully');</script>";
            }
            return RedirectToAction("listProducts", "ManageProduct");
        }

        [HttpPost]
        
        public ActionResult updateProductImage(Product pr, HttpPostedFileBase file)
        {
            string uploadFolder = Request.PhysicalApplicationPath + "ProductImgs\\"; //upload folder
            var myUniqueFileName = string.Format(@"{0}", Guid.NewGuid()); //GENERATE A UNIQUE FILE NAME
            if (file != null)
            {
                string extension = System.IO.Path.GetExtension(file.FileName);
                file.SaveAs(uploadFolder + myUniqueFileName + extension);
                using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
                {
                    sqlCon.Open();
                    MySqlCommand sqlCmd = new MySqlCommand("updateProdImg", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("prID", pr.productIdLG);
                    sqlCmd.Parameters.AddWithValue("pImg", myUniqueFileName + extension);
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
            }

            return RedirectToAction("editProduct", "ManageProduct", new { pid = pr.productIdLG });
        }
    }
}