﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Amritulya.Models;
using MySql.Data.MySqlClient;

namespace Amritulya.Controllers
{
    [Authorize]
    public class ManageSubProductController : Controller
    {
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: ManageSubProduct
        public ActionResult listSubProducts()
        {
            var model = new List<SubProduct>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("listSubProducts", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                //sqlDA.SelectCommand.Parameters.AddWithValue("bOwner", name);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int c = dtbl.Rows.Count;
                for (int i = 0; i < c; i++)
                {
                    var pr = new SubProduct();
                    pr.subproductNameLG = dtbl.Rows[i]["subproductNameLG"].ToString();
                    string img = dtbl.Rows[i]["subproductImgNameLG"].ToString();
                    pr.subproductImgNameLG = "/SubProdImgs/" + img;
                    pr.subproductCategory = dtbl.Rows[i]["CategoryName"].ToString();
                    pr.subproductPriceLG = dtbl.Rows[i]["subproductPriceLG"].ToString();
                    pr.subproductAvailability = dtbl.Rows[i]["subproductAvailability"].ToString();
                    pr.subproductIdLG = Convert.ToInt32(dtbl.Rows[i]["subproductIdLG"].ToString());
                    pr.subproductRank = Convert.ToInt32(dtbl.Rows[i]["subproductRank"].ToString());
                    pr.subproductAddedBy = dtbl.Rows[i]["subproductAddedBy"].ToString();
                    //pr.subproductWeight = dtbl.Rows[i]["subproductWeight"].ToString();
                    //pr.subproductColors = dtbl.Rows[i]["subproductColors"].ToString();
                    DateTime dt = Convert.ToDateTime(dtbl.Rows[i]["subproductAddDate"].ToString());
                    pr.subproductAddDate = dt.ToString("dd/MM/yyyy");
                    model.Add(pr);
                }
                return View("subproductDisplay", model);
            }
        }

        public ActionResult deleteSubProduct(string pid)
        {
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open();
                MySqlCommand sqlCmd = new MySqlCommand("deleteSubProduct", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("sprID", pid.Trim());
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();
            }
            return RedirectToAction("listSubProducts", "ManageSubProduct");
        }

        
        public ActionResult editSubProduct(string pid)
        {
            var list = new List<Product>();
            list = loadCategory();
            var p = new SubProduct();
            p.category = list;

            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("loadSubProduct", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("sprID", pid);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                //var bk = new book();
                p.subproductNameLG = dtbl.Rows[0]["subproductNameLG"].ToString();
                string img = dtbl.Rows[0]["subproductImgNameLG"].ToString();
                p.subproductImgNameLG = "/SubProdImgs/" + img;
                p.subproductCategory = dtbl.Rows[0]["CategoryName"].ToString();
                p.subproductIdLG = Convert.ToInt32(dtbl.Rows[0]["subproductIdLG"].ToString());
                p.subproductPriceLG = dtbl.Rows[0]["subproductPriceLG"].ToString();
                p.subproductRank = Convert.ToInt32(dtbl.Rows[0]["subproductRank"].ToString());
                p.subproductDescriptionLG = dtbl.Rows[0]["subproductDescriptionLG"].ToString();
                p.subproductAvailability = dtbl.Rows[0]["subproductAvailability"].ToString();
                p.subproductWeight = dtbl.Rows[0]["subproductWeight"].ToString();
                p.subproductColors = dtbl.Rows[0]["subproductColors"].ToString();
                //cp.empId = dtbl.Rows[i]["empId"].ToString();                           
                return View("subproductEditor", p);
            }
            //return View();
        }

        private List<Product> loadCategory()
        {
            var l = new List<Product>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring)) //to create a new sql connection
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("listProducts", sqlCon); //stored procedure to view all products
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                sqlCon.Close();
                int c = dtbl.Rows.Count;

                for (int k = 0; k < c; k++)
                {
                    var ct = new Product();
                    ct.productNameLG = (dtbl.Rows[k]["productNameLG"].ToString());
                    l.Add(ct);
                }
                return l;
            }
        }

        [HttpPost]
        
        public ActionResult updateSubProduct(SubProduct p)
        {
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open();
                MySqlCommand sqlCmd = new MySqlCommand("updateSubProductDetails", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("sprID", p.subproductIdLG);
                sqlCmd.Parameters.AddWithValue("spName", p.subproductNameLG.Trim());
                sqlCmd.Parameters.AddWithValue("spRank", p.subproductRank.ToString().Trim());
                sqlCmd.Parameters.AddWithValue("spPrice", p.subproductPriceLG);
                sqlCmd.Parameters.AddWithValue("spDesc", p.subproductDescriptionLG);
                sqlCmd.Parameters.AddWithValue("spStatus", p.subproductAvailability);
                sqlCmd.Parameters.AddWithValue("spWgt", p.subproductWeight);
                sqlCmd.Parameters.AddWithValue("spColor", p.subproductColors);
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();
                //TempData["msg"] = "<script>alert('Book Added Successfully');</script>";
            }
            return RedirectToAction("listSubProducts", "ManageSubProduct");
        }

        [HttpPost]
        
        public ActionResult updateSubProductImage(SubProduct pr, HttpPostedFileBase file)
        {
            string uploadFolder = Request.PhysicalApplicationPath + "SubProdImgs\\"; //upload folder
            var myUniqueFileName = string.Format(@"{0}", Guid.NewGuid()); //GENERATE A UNIQUE FILE NAME
            if (file != null)
            {
                string extension = System.IO.Path.GetExtension(file.FileName);
                file.SaveAs(uploadFolder + myUniqueFileName + extension);
                using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
                {
                    sqlCon.Open();
                    MySqlCommand sqlCmd = new MySqlCommand("updatesubProdImg", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("sprID", pr.subproductIdLG);
                    sqlCmd.Parameters.AddWithValue("spImg", myUniqueFileName + extension);
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
            }

            return RedirectToAction("editSubProduct", "ManageSubProduct", new { pid = pr.subproductIdLG });
        }
    }
}