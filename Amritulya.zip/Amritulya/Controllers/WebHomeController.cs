﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Amritulya.Models;
using MySql.Data.MySqlClient;

namespace Amritulya.Controllers
{
    public class WebHomeController : Controller
    {
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: WebHome
        public ActionResult viewHome()
        {
            user us = new user();
            us.userRegMessage = "";
            return View("mainHome",us);
        }
        public ActionResult contactUs(user us)
        {
           //sendMail(us);
            us.userRegMessage = "Request Posted Successfully! Will get back to you soon.";
            return View("mainHome",us);
        }
        private void sendMail(user u)
        {
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open();
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("showEmail", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dtdbl = new DataTable();
                sqlDA.Fill(dtdbl);
                string em = dtdbl.Rows[0][0].ToString();
                string pass = dtdbl.Rows[0][1].ToString();
                sqlCon.Close();
                string fromaddr = em;
                string password = pass;
                MailMessage msg = new MailMessage();
                msg.Subject = "User Requests";
                msg.From = new MailAddress(fromaddr);
                msg.Body = "Hi" + "\r\n" + "\r\n"  + "A customer has contacted team Little Garden for a query. Find the details below : " + "\r\n" + "\r\n" + "Name : " +u.userName+ "\r\n" + "\r\n" + "Contact Number : "+u.userContact + "\r\n" + "\r\n" + "Email : " +u.userEmail+ "\r\n" + "\r\n" + "Query : " +u.userMessage+ "\r\n" +"Please contact him and reply to answer his/her question."+ "\r\n" + "\r\n" + "Team Little Garden";
                //msg.IsBodyHtml = true;
                msg.To.Add(new MailAddress(fromaddr));
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.office365.com";
                //smtp.Port = 587;
                smtp.UseDefaultCredentials = false;
                smtp.EnableSsl = true;
                NetworkCredential nc = new NetworkCredential(fromaddr, password);
                smtp.Credentials = nc;
                smtp.Send(msg);
                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Order Confirmed')", true);
            }
           
        }
    }
}