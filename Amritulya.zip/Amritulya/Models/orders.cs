﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Amritulya.Models
{
    public class orders
    {
        public int orderID {get;set;}
        public int orderCustomerID {get;set;}
        public int orderProductID {get;set;}
        public string orderProductName { get; set; }
        public string userFirstName { get; set; }
        public string userLastName { get; set; }
        public string orderDate {get;set;}
        public string orderAddress {get;set;}
        public string orderEmail {get;set;}
        public string orderAmount {get;set;}
        public string orderQuantity {get;set;}
        public string orderStatus {get; set;}
        public string orderPhone { get; set; }
        public string orderUnitPrice { get; set; }
        public string shipmentCompany { get; set; }
        public string shipmentID { get; set; }
        public string orderImageName { get; set; }
        public string orderCountMessage { get; set; }
        public string orderType { get; set; }
        public string orderPriorStatus { get; set; }
    }
}