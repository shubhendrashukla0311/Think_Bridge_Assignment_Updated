﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Amritulya.Models
{
    public class user
    {
        public string userId { get; set; }
        public string userName { get; set; }
        public string userEmail { get; set; }
        public string userContact { get; set;}
        public string userPassword { get; set; }
        public string userConfirmPassword { get; set; }
        public string userAgree { get; set; }
        public string userMessage { get; set; }
        public string userRegMessage { get; set; }
        public string bufferString { get; set; }
        public string termsString { get; set; }
    }
}