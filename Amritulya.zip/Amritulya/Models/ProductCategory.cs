﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Amritulya.Models
{
    public class ProductCategory
    {
        public int categoryID { get; set; }
        public string categoryName { get; set; }
        public string categoryAddDate { get; set; }
        public string categoryAddedBy { get; set; }
    }
}