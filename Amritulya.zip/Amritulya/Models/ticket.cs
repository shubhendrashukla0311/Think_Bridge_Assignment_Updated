﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Amritulya.Models
{
    public class ticket
    {
        public string flag { get; set; }
        public string userName { get; set; }
        public string userEmail { get; set; }
        public string userContact { get; set; }
        public string userMessage { get; set; }
        public string userRegMessage { get; set; }
    }
}