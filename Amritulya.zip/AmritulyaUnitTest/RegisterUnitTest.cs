﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;
using Amritulya;
using Amritulya.Controllers;
using Amritulya.Models;
using System.Web.Security;
using System.Web;
using System.IO.Pipes;

namespace AmritulyaUnitTest
{
    [TestClass]
    public class RegisterUnitTest
    {
        [TestMethod]
        public void TestRegisterLoad() //test if register screen is loading
        {
            RegisterController controller = new RegisterController();
            string sr = null;
            //act
            ViewResult result = controller.register(sr) as ViewResult;

            //assert            
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public void TestMethod1() //check if register of new user
        {
            RegisterController controller = new RegisterController();
            user ur = new user();
            ur.userName = "Shushma Shukla";
            ur.userEmail = "shushma_demo9@gmail.com"; //remember to give unique email
            ur.userContact = "1234567890";
            ur.userConfirmPassword = "user";
            ur.userPassword = "user";
            
            //act
            var result = (RedirectToRouteResult)controller.register(ur);

            result.RouteValues["action"].Equals("verifyUser");
            result.RouteValues["controller"].Equals("Login");

            //assert
            Assert.AreEqual("verifyUser", result.RouteValues["action"]);
            Assert.AreEqual("Login", result.RouteValues["controller"]);
        }

        [TestMethod]
        public void TestMethodExistingUser() //check if register of existing user
        {
            RegisterController controller = new RegisterController();
            user ur = new user();
            ur.userName = "Shushma Shukla";
            ur.userEmail = "shushma@gmail.com"; //remember to give unique email
            ur.userContact = "1234567890";
            ur.userConfirmPassword = "user";
            ur.userPassword = "user";

            //act
            ViewResult result = controller.register(ur) as ViewResult;

            //assert
            Assert.IsNotNull(result.Model); //check if data for order is returned without any error.


            ViewResult viewResult = (ViewResult)result;
            user model = (user)viewResult.Model;
            Assert.IsNotNull(model.userRegMessage);
            Assert.AreEqual("User Already Exists", model.userRegMessage);
        }

        [TestMethod]
        public void TestMethodPasswordMismatch() //check if confirm and password field match
        {
            RegisterController controller = new RegisterController();
            user ur = new user();
            ur.userName = "Shushma Shukla";
            ur.userEmail = "shushma_demo2@gmail.com"; //remember to give unique email
            ur.userContact = "1234567890";
            ur.userConfirmPassword = "user";
            ur.userPassword = "use";

            //act
            ViewResult result = controller.register(ur) as ViewResult;

            //assert
            Assert.IsNotNull(result.Model); //check if data for order is returned without any error.


            ViewResult viewResult = (ViewResult)result;
            user model = (user)viewResult.Model;
            Assert.IsNotNull(model.userRegMessage);
            Assert.AreEqual("Password and Confirm Password Not Match", model.userRegMessage);
        }
    }
}
