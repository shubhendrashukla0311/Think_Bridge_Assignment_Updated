﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;
using Amritulya;
using Amritulya.Controllers;
using Amritulya.Models;
namespace AmritulyaUnitTest
{
    [TestClass]
    public class AdminAddControllerTest
    {
        //to test if add admin page loads
        [TestMethod]
        public void addAdmin()
        {

            //arrange
            AdminAddController controller = new AdminAddController();
            //act
            ViewResult result = controller.addAdmin() as ViewResult;

            //assert
            
            Assert.IsNotNull(result);
        }

        [TestMethod]
        [HttpPost]
        public void addNewAdmin() //to test that new admin is getting added
        {

            //arrange
            AdminAddController controller = new AdminAddController();
            //act
            user u = new user();
            u.userName = "Shubhendra Shukla";
            u.userEmail = "shubhendra.shukla0311@gmail.com";
            u.userPassword = "admin";
            u.userContact = "9793155956";

            var result = (RedirectToRouteResult)controller.addAdmin(u);

            result.RouteValues["action"].Equals("adminHomePage");
            result.RouteValues["controller"].Equals("Admin");

            //assert
            Assert.AreEqual("adminHomePage", result.RouteValues["action"]);
            Assert.AreEqual("Admin", result.RouteValues["controller"]);
        }

        [TestMethod]
        [HttpPost]
        public void addNewAdminErrorTest() //to test if any error happens then if exception handeled
        {

            //arrange
            AdminAddController controller = new AdminAddController();
            //act
            user u = new user();
            u.userName = "Shubhendra Shukla";
            u.userEmail = "shubhendra.shukla0311@gmail.com";
            //don't pass password to cause an exception
            u.userContact = "9793155956";

            var result = (RedirectToRouteResult)controller.addAdmin(u);

            result.RouteValues["action"].Equals("addAdmin");
            result.RouteValues["controller"].Equals("AdminAdd");

            //assert
            Assert.AreEqual("addAdmin", result.RouteValues["action"]);
            Assert.AreEqual("AdminAdd", result.RouteValues["controller"]);
        }

    }

    [TestClass]
    public class LoginControllerTest
    {
        //user u = new user();

        [TestMethod]
        public void verifyUser()
        {

            //arrange
            LoginController controller = new LoginController();
            //act


            var result = (RedirectToRouteResult)controller.verifyUser();

            result.RouteValues["action"].Equals("register");
            result.RouteValues["controller"].Equals("Register");

            //assert
            Assert.AreEqual("register", result.RouteValues["action"]);
            Assert.AreEqual("Register", result.RouteValues["controller"]);
        }

        [TestMethod]
        [HttpPost] //check in-valid/no user found success
        public void verifyInvalidUser()
        {

            //arrange
            LoginController controller = new LoginController();
            //act
            user u = new user();
            u.userEmail = "shubhendra.shukla1994@gmail.com";
            u.userPassword = "use";

            var result = (RedirectToRouteResult)controller.verifyUser(u);

            result.RouteValues["action"].Equals("register");
            result.RouteValues["controller"].Equals("Register");
            result.RouteValues["userMessage"].Equals("Invalid Credentials !");
            //var msg= COnvert.toString(result.RouteValues["routeValues"]);

            //assert
            Assert.AreEqual("register", result.RouteValues["action"]);
            Assert.AreEqual("Register", result.RouteValues["controller"]);
            Assert.AreEqual("Invalid Credentials !", result.RouteValues["userMessage"]);
        }

        [TestMethod]
        [HttpPost] //check in-valid/no user found success
        public void verifyNoUser()
        {

            //arrange
            LoginController controller = new LoginController();
            //act
            user u = new user();
            u.userEmail = "shubhendra.shukl@gmail.com"; //a user that does not exist
            u.userPassword = "user";

            var result = (RedirectToRouteResult)controller.verifyUser(u);

            result.RouteValues["action"].Equals("register");
            result.RouteValues["controller"].Equals("Register");
            result.RouteValues["userMessage"].Equals("User Not Found !");
            //var msg= COnvert.toString(result.RouteValues["routeValues"]);

            //assert
            Assert.AreEqual("register", result.RouteValues["action"]);
            Assert.AreEqual("Register", result.RouteValues["controller"]);
            Assert.AreEqual("User Not Found !", result.RouteValues["userMessage"]);
        }

        [TestMethod]
        
        public void verifyHomeForGuest()
        {

            //arrange
            WebHomeController controller = new WebHomeController();
           
           
            //act
            ViewResult result = controller.viewHome() as ViewResult;

            //assert

            Assert.IsNotNull(result);
        }
        [TestMethod]
        public void verifyHomeForRegistered()
        {

            //arrange
            UserHomeController controller = new UserHomeController();


            //act
            ViewResult result = controller.viewHome() as ViewResult;

            //assert

            Assert.IsNotNull(result);
        }
    }
}
