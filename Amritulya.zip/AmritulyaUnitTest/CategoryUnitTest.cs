﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;
using Amritulya;
using Amritulya.Controllers;
using Amritulya.Models;
using System.Web.Security;
using System.Web;
using System.IO.Pipes;

namespace AmritulyaUnitTest
{
    [TestClass]
    public class CategoryUnitTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            ProductCategoryController controller = new ProductCategoryController();

            //act
            ViewResult result = controller.viewCategories() as ViewResult;

            //assert
            Assert.IsNotNull(result.Model); //check if list of sub product is returned without any error
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TestDeleteCategory()
        {
            ProductCategoryController controller = new ProductCategoryController();
            //add a new category and then delete it.
            string catId = "3"; //pass id of category to be deleted
            //act
            var result = (RedirectToRouteResult)controller.removeCategory(catId);

            result.RouteValues["action"].Equals("viewCategories");
            result.RouteValues["controller"].Equals("ProductCategory");

            //assert
            Assert.AreEqual("viewCategories", result.RouteValues["action"]);
            Assert.AreEqual("ProductCategory", result.RouteValues["controller"]);

            //check list of sub products and the deleted id should not be there

            ViewResult resultAfter = controller.viewCategories() as ViewResult;

            //assert
            Assert.IsNotNull(resultAfter.Model); //check in list of sub product the deleted product id should not be there

        }

        [TestMethod]
        public void TestCategoryDetailFetch()
        {

            //set category Id from your category list
            string filter = "1";

            //set the filter variable to filters among all choices available
            ProductCategoryController controller = new ProductCategoryController();

            //act
            ViewResult result = controller.fetchCategoryDetails(filter) as ViewResult;

            //assert
            Assert.IsNotNull(result.Model); //check if data for category is returned without any error.


            ViewResult viewResult = (ViewResult)result;
            ProductCategory model = (ProductCategory)viewResult.Model;
            Assert.IsNotNull(model.categoryID);
            Assert.AreEqual(Convert.ToInt32(filter), model.categoryID);
            //check category id is matching to the category id sent
            //no need to test by not passing an invalid category id as order for edit is selected from the category list.


            Assert.IsNotNull(result); //check if it goes to view

        }

        [TestMethod]
        public void TestMethod5() //test to check if on sending sub product update for a sub product
        {

            //create a product object, in view already getting values from the click on edit product button
            ProductCategory pr = new ProductCategory();
            pr.categoryID = 1;
            pr.categoryName = "Food Orders";
            pr.categoryAddedBy = "DemoEdit";  //try updating added by
            
            //set the filter variable to filters among all choices available
            ProductCategoryController controller = new ProductCategoryController();

            //act
            var result = (RedirectToRouteResult)controller.editCategoryDetails(pr);

            result.RouteValues["action"].Equals("viewCategories");
            result.RouteValues["controller"].Equals("ProductCategory");

            //assert
            Assert.AreEqual("viewCategories", result.RouteValues["action"]);
            Assert.AreEqual("ProductCategory", result.RouteValues["controller"]);

            //then get details on the category and check if it has been updated

            //act //get details of same product category
            ViewResult resultAfter = controller.fetchCategoryDetails(Convert.ToString(pr.categoryID)) as ViewResult;

            //assert
            Assert.IsNotNull(resultAfter.Model); //check if data for category is returned without any error.
                                                 //check category id is matching to the category id sent
                                                 //check whatever field you updated got updated in the model
                                                 //no need to test by not passing an invalid category id as category for edit is selected from the category list.
            ViewResult viewResult = (ViewResult)resultAfter;
            ProductCategory model = (ProductCategory)viewResult.Model;
            Assert.IsNotNull(model.categoryAddedBy);

            Assert.AreEqual(pr.categoryAddedBy, model.categoryAddedBy);            //compare for whatever field you have passed
            //updated category added by so compared with what updated
        }
    }
}
