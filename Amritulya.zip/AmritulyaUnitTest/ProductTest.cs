﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;
using Amritulya;
using Amritulya.Controllers;
using Amritulya.Models;
using System.Web.Security;
using System.Web;
using System.IO.Pipes;

namespace AmritulyaUnitTest
{
    [TestClass]
    public class ProductTest
    {

        [TestMethod]
        public void TestProductAddLoad() //test if product add screen is loading
        {
            ProductController controller = new ProductController();

            //act
            ViewResult result = controller.addProduct() as ViewResult;

            //assert            
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TestRawMaterialTileLoad() //test if food order product add screen is loading
        {
            ProductTileController controller = new ProductTileController();
            HttpCookie authCookie = null;
            //act
            ViewResult result = controller.viewGardeningProductTiles() as ViewResult;

            //assert            
            Assert.IsNotNull(result); //check in model if all food orders returned or not
        }
        [TestMethod]
        public void TestProductTileLoad() //test if raw material product screen is loading
        {
            ProductTileController controller = new ProductTileController();
            HttpCookie authCookie = null;
            //act
            ViewResult result = controller.viewKitProductTiles() as ViewResult;

            //assert            
            Assert.IsNotNull(result); //check in model if all raw material returned or not
        }
        [TestMethod]
        public void TestMethod1()
        {
            ManageProductController controller = new ManageProductController();

            //act
            ViewResult result = controller.listProducts() as ViewResult;

            //assert
            Assert.IsNotNull(result.Model); //check if list of product is returned without any error
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TestDeleteProduct()
        {
            ManageProductController controller = new ManageProductController();
            //add a new product and then delete it.
            string productID = "5"; //pass id of product to be deleted
            //act
            var result = (RedirectToRouteResult)controller.deleteProduct(productID);

            result.RouteValues["action"].Equals("listProducts");
            result.RouteValues["controller"].Equals("ManageProduct");

            //assert
            Assert.AreEqual("listProducts", result.RouteValues["action"]);
            Assert.AreEqual("ManageProduct", result.RouteValues["controller"]);

            //check list of products and the deleted id should not be there

            ViewResult resultAfter = controller.listProducts() as ViewResult;

            //assert
            Assert.IsNotNull(resultAfter.Model); //check in list of product the deleted product id should not be there
            
        }

        [TestMethod]
        public void TestProductDetailFetch()
        {

            //set product Id from your order list
            string filter = "1";

            //set the filter variable to filters among all choices available
            ManageProductController controller = new ManageProductController();

            //act
            ViewResult result = controller.editProduct(filter) as ViewResult;

            //assert
            Assert.IsNotNull(result.Model); //check if data for order is returned without any error.


            ViewResult viewResult = (ViewResult)result;
            Product model = (Product)viewResult.Model;
            Assert.IsNotNull(model.productIdLG);
            Assert.AreEqual(Convert.ToInt32(filter), model.productIdLG);
            //check product id is matching to the product id sent
            //no need to test by not passing an invalid product id as order for edit is selected from the product list.


            Assert.IsNotNull(result); //check if it goes to view

        }

        [TestMethod]
        public void TestMethod5() //test to check if on sending product update for a product
        {

            //create a product object, in view already getting values from the click on edit product button
            Product pr = new Product();
            pr.productIdLG = 1;
            pr.productNameLG = "Beverages";
            pr.productRank = 1;  //pass id of product to be updated
            pr.productDescriptionLG = "Enjoy our range of soothing beverages.";
            pr.productAvailability = "UnAvailable"; //try changing product Availability
            //set the filter variable to filters among all choices available
            ManageProductController controller = new ManageProductController();

            //act
            var result = (RedirectToRouteResult)controller.updateProduct(pr);

            result.RouteValues["action"].Equals("listProducts");
            result.RouteValues["controller"].Equals("ManageProduct");

            //assert
            Assert.AreEqual("listProducts", result.RouteValues["action"]);
            Assert.AreEqual("ManageProduct", result.RouteValues["controller"]);

            //then get details on the order and check if order has been updated

            //act //get details of same product
            ViewResult resultAfter = controller.editProduct(Convert.ToString(pr.productIdLG)) as ViewResult;

            //assert
            Assert.IsNotNull(resultAfter.Model); //check if data for product is returned without any error.
                                                 //check product id is matching to the product id sent
                                                 //check whatever field you updated got updated in the model
                                                 //no need to test by not passing an invalid product id as product for edit is selected from the product list.
            ViewResult viewResult = (ViewResult)resultAfter;
            Product model = (Product)viewResult.Model;
            Assert.IsNotNull(model.productAvailability);

            Assert.AreEqual(pr.productAvailability, model.productAvailability);            //compare for whatever field you have passed
            //updated order status so compared with what updated
        }
    }
}
