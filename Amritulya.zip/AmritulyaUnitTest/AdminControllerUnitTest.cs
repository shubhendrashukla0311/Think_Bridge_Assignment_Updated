﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;
using Amritulya;
using Amritulya.Controllers;
using Amritulya.Models;
using System.Web.Security;
using System.Web;
using MySql.Data.MySqlClient;


namespace AmritulyaUnitTest
{
    [TestClass]
    public class AdminControllerUnitTest
    {
        [TestMethod]
        public void TestMethod1() //test if admin home page loads when an admin logs in
        {
            //arrange
            AdminController controller = new AdminController();
           
            //act
            ViewResult result = controller.adminHomePage() as ViewResult;

            //assert

            Assert.IsNotNull(result);
        }
    }

    [TestClass]
    public class EditDeleteAdminControllerUnitTest
    {
        [TestMethod]
        public void TestMethod1() //test if admin gets deleted
        {
            //to test this first add a new admin from add admin
            //no need to check if admin exists or not as delete is being done from list of admin from edit/delete admin
            //add a new admin and pass the id of the admin here to delete
            //arrange
            EditDeleteAdminController controller = new EditDeleteAdminController();

            //act
            var result = (RedirectToRouteResult)controller.removeAdmin("28");

            result.RouteValues["action"].Equals("adminEditor");
            result.RouteValues["controller"].Equals("EditDeleteAdmin");

            //assert
            Assert.AreEqual("adminEditor", result.RouteValues["action"]);
            Assert.AreEqual("EditDeleteAdmin", result.RouteValues["controller"]);
        }
    }

    //List Orders Test Class
    [TestClass]
    public class ListOrdersControllerUnitTest
    {
        [TestMethod]
        public void TestMethod1() //test to check if list of all orders returned or not
        {

            ListOrdersController controller = new ListOrdersController();

            //act
            ViewResult result = controller.listAllOrders() as ViewResult;



            //assert
            Assert.IsNotNull(result.Model); //check if data for order is returned without any error
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TestMethod2() //test to check if list of all orders gets filtered  for filter being sent
        {

            //All -- List all orders
            //Today -- List orders that came today
            //Date -- Sort orders by date
            //Amount -- Sort orders by amount of order
            //Confirmed -- Select orders where order status is confirmed
            //Shipped -- select order where order status is shipped
            //Delivered -- select order where order status is delivered
            //Guest -- select orders placed by guest
            //Customer -- select orders placed by registered customers
            string filter = "Guest";

            //set the filter variable to filters among all choices available
            ListOrdersController controller = new ListOrdersController();

            //act
            ViewResult result = controller.showFilteredOrders(filter) as ViewResult;

            //assert
            Assert.IsNotNull(result.Model); //check if data for order is returned without any error and debug model to check if correct data comming
            
            Assert.IsNotNull(result);            
        }

        [TestMethod]
        public void TestMethod3() //test to check if on selecting among list of orders if correct order details being returned
        {

          //set order Id from your order list
            string filter = "1";

            //set the filter variable to filters among all choices available
            ListOrdersController controller = new ListOrdersController();

            //act
            ViewResult result = controller.editOrderDetails(filter) as ViewResult;

            //assert
            Assert.IsNotNull(result.Model); //check if data for order is returned without any error.


            ViewResult viewResult = (ViewResult)result;
            orders model = (orders)viewResult.Model;
            Assert.IsNotNull(model.orderID);
            Assert.AreEqual(Convert.ToInt32(filter), model.orderID);
            //check order id is matching to the order id sent
            //no need to test by not passing an invalid order id as order for edit is selected from the order list.


            Assert.IsNotNull(result); //check if it goes to view

        }

        [TestMethod]
        public void TestMethod4() //test to check if on sending order update for an order the order values get updated without an error
        {

            //create an order object, in view already getting values from the click on edit order button
            orders or = new orders();
            or.orderID = 1;
            or.orderPriorStatus = "Confirmed";
            or.orderStatus = "Shipped"; //try updating order status
            or.shipmentCompany = "India Post";
            or.shipmentID = "SP1234";
            //set the filter variable to filters among all choices available
            ListOrdersController controller = new ListOrdersController();

            //act
            var result = (RedirectToRouteResult)controller.updateOrder(or);

            result.RouteValues["action"].Equals("listAllOrders");
            result.RouteValues["controller"].Equals("ListOrders");

            //assert
            Assert.AreEqual("listAllOrders", result.RouteValues["action"]);
            Assert.AreEqual("ListOrders", result.RouteValues["controller"]);

            //then get details on the order and check if order has been updated
            
            //act
            ViewResult resultAfter = controller.editOrderDetails(Convert.ToString(or.orderID)) as ViewResult;

            //assert
            Assert.IsNotNull(resultAfter.Model); //check if data for order is returned without any error.
                                                 //check order id is matching to the order id sent
                                                 //check whatever field you updated got updated in the model
                                                 //no need to test by not passing an invalid order id as order for edit is selected from the order list.
            ViewResult viewResult = (ViewResult)resultAfter;
            orders model = (orders)viewResult.Model;
            Assert.IsNotNull(model.orderStatus);
            
            Assert.AreEqual(or.orderStatus, model.orderStatus);            //compare for whatever field you have passed
            //updated order status so compared with what updated
        }

        [TestMethod]
        public void TestMethod5() //test to check if on selecting among list of orders if receipt is being generated
        {

            //set order Id from your order list
            string filter = "1";

            //set the filter variable to filters among all choices available
            ListOrdersController controller = new ListOrdersController();

            //act
            ViewResult result = controller.printOrderReceipt(filter) as ViewResult;

            //assert
            Assert.IsNotNull(result.Model); //check if data for order is returned without any error.


            ViewResult viewResult = (ViewResult)result;
            orders model = (orders)viewResult.Model;
            Assert.IsNotNull(model.orderID);
            Assert.AreEqual(Convert.ToInt32(filter), model.orderID);
            //check order id is matching to the order id sent
            //no need to test by not passing an invalid order id as order for edit is selected from the order list.


            Assert.IsNotNull(result); //check if it goes to view

        }
    }




}
