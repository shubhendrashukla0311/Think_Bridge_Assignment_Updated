﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;
using Amritulya;
using Amritulya.Controllers;
using Amritulya.Models;
using System.Web.Security;
using System.Web;
using System.IO.Pipes;

namespace AmritulyaUnitTest
{
    [TestClass]
    public class SubProductTest
    {
        [TestMethod]
        public void TestSubProductAddLoad() //test if sub product add screen is loading
        {
            SubProductController controller = new SubProductController();

            //act
            ViewResult result = controller.addSubProduct() as ViewResult;

            //assert            
            Assert.IsNotNull(result);
        }


        [TestMethod]
        public void TestSubProductDetailsLoad() //test if sub product detail is loading
        {
            SubProductDetailController controller = new SubProductDetailController();
            string id = "1";
            //act
            ViewResult result = controller.displaySubProductDetail(id) as ViewResult;

            //assert            
            Assert.IsNotNull(result); //check in model if all food orders returned or not

            ViewResult viewResult = (ViewResult)result;
            SubProduct model = (SubProduct)viewResult.Model;
            Assert.IsNotNull(model.subproductIdLG);
            Assert.AreEqual(Convert.ToInt32(id), model.subproductIdLG); //check if sent id and returned id are same
        }

        //test to check if sub product tiles are loading
        [TestMethod]
        public void TestSubProductTileLoad() //test if all tiles belonging to a category are loading
        {

            SubProductTilesController controller = new SubProductTilesController();
           
            string prodId = "1"; //pass product id for which you want to display sub products
            //pass only correct id as only on clicking to a product sub prods under it are listed not all
            //act
            ViewResult result = controller.displaySubProductTiles(prodId) as ViewResult;

            //assert            
            Assert.IsNotNull(result); //check in model if all sub product of that category are returned or not
         
        }

        [TestMethod]
        public void TestMethod1()
        {
            ManageSubProductController controller = new ManageSubProductController();

            //act
            ViewResult result = controller.listSubProducts() as ViewResult;

            //assert
            Assert.IsNotNull(result.Model); //check if list of sub product is returned without any error
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TestDeleteSubProduct()
        {
            ManageSubProductController controller = new ManageSubProductController();
            //add a new sub product and then delete it.
            string subProductID = "9"; //pass id of sub product to be deleted
            //act
            var result = (RedirectToRouteResult)controller.deleteSubProduct(subProductID);

            result.RouteValues["action"].Equals("listSubProducts");
            result.RouteValues["controller"].Equals("ManageSubProduct");

            //assert
            Assert.AreEqual("listSubProducts", result.RouteValues["action"]);
            Assert.AreEqual("ManageSubProduct", result.RouteValues["controller"]);

            //check list of sub products and the deleted id should not be there

            ViewResult resultAfter = controller.listSubProducts() as ViewResult;

            //assert
            Assert.IsNotNull(resultAfter.Model); //check in list of sub product the deleted product id should not be there

        }
        [TestMethod]
        public void TestSubProductDetailFetch()
        {

            //set sub product Id from your order list
            string filter = "1";

            //set the filter variable to filters among all choices available
            ManageSubProductController controller = new ManageSubProductController();

            //act
            ViewResult result = controller.editSubProduct(filter) as ViewResult;

            //assert
            Assert.IsNotNull(result.Model); //check if data for sub product is returned without any error.


            ViewResult viewResult = (ViewResult)result;
            SubProduct model = (SubProduct)viewResult.Model;
            Assert.IsNotNull(model.subproductIdLG);
            Assert.AreEqual(Convert.ToInt32(filter), model.subproductIdLG);
            //check sub product id is matching to the sub product id sent
            //no need to test by not passing an invalid sub product id as order for edit is selected from the sub product list.


            Assert.IsNotNull(result); //check if it goes to view

        }

        [TestMethod]
        public void TestMethod5() //test to check if on sending sub product update for a sub product
        {

            //create a product object, in view already getting values from the click on edit product button
            SubProduct pr = new SubProduct();
            pr.subproductIdLG = 1;
            pr.subproductNameLG = "Masala Chai";
            pr.subproductRank = 1;  //pass id of sub product to be updated
            pr.subproductPriceLG = "15";
            pr.subproductDescriptionLG = "Enjoy our range of soothing beverages.";
            pr.subproductAvailability = "UnAvailable"; //try changing product Availability
            pr.subproductWeight ="";
            pr.subproductColors ="";
            //set the filter variable to filters among all choices available
            ManageSubProductController controller = new ManageSubProductController();

            //act
            var result = (RedirectToRouteResult)controller.updateSubProduct(pr);

            result.RouteValues["action"].Equals("listSubProducts");
            result.RouteValues["controller"].Equals("ManageSubProduct");

            //assert
            Assert.AreEqual("listSubProducts", result.RouteValues["action"]);
            Assert.AreEqual("ManageSubProduct", result.RouteValues["controller"]);

            //then get details on the order and check if order has been updated

            //act //get details of same product
            ViewResult resultAfter = controller.editSubProduct(Convert.ToString(pr.subproductIdLG)) as ViewResult;

            //assert
            Assert.IsNotNull(resultAfter.Model); //check if data for product is returned without any error.
                                                 //check product id is matching to the product id sent
                                                 //check whatever field you updated got updated in the model
                                                 //no need to test by not passing an invalid product id as product for edit is selected from the product list.
            ViewResult viewResult = (ViewResult)resultAfter;
            SubProduct model = (SubProduct)viewResult.Model;
            Assert.IsNotNull(model.subproductAvailability);

            Assert.AreEqual(pr.subproductAvailability, model.subproductAvailability);            //compare for whatever field you have passed
            //updated order status so compared with what updated
        }



    }
}
